#!/usr/bin/env node

/**
 * Vietnamese Market Data Socket Test Script
 * Test VNINDEX and VIC symbol data feeds
 */

const io = require('socket.io-client');
const readline = require('readline');

// Configuration
const CONFIG = {
    SERVER_URL: 'ws://localhost:3000/market-data',
    SYMBOLS: {
        VIC: 'VIC',          // Vingroup
        VCB: 'VCB',          // Vietcombank
        FPT: 'FPT',          // FPT Corporation
        MSN: 'MSN',          // Masan Group
        VHM: 'VHM',          // Vinhomes
        GAS: 'GAS',          // PetroVietnam Gas
        CTG: 'CTG',          // VietinBank
        BID: 'BID',          // BIDV
        VRE: 'VRE',          // Vincom Retail
        HPG: 'HPG'           // Hoa Phat Group
    },
    INDICES: {
        VNINDEX: 'VNINDEX',  // VN-Index
        VN30: 'VN30',        // VN30 Index
        HNXINDEX: 'HNXINDEX' // HNX-Index
    }
};

class VietnameseMarketTester {
    constructor() {
        this.socket = null;
        this.isConnected = false;
        this.messageCount = 0;
        this.subscriptions = new Set();
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
    }

    log(message, type = 'INFO') {
        const timestamp = new Date().toLocaleTimeString('vi-VN');
        const colors = {
            INFO: '\x1b[36m',      // Cyan
            SUCCESS: '\x1b[32m',   // Green
            ERROR: '\x1b[31m',     // Red
            DATA: '\x1b[33m',      // Yellow
            WARNING: '\x1b[35m'    // Magenta
        };
        const reset = '\x1b[0m';
        const color = colors[type] || colors.INFO;

        this.messageCount++;
        console.log(`${color}[${timestamp}] #${this.messageCount} [${type}] ${message}${reset}`);
    }

    async connect(jwtToken) {
        return new Promise((resolve, reject) => {
            if (this.socket) {
                this.socket.disconnect();
            }

            this.log(`🔄 Connecting to Vietnamese market data server: ${CONFIG.SERVER_URL}`);

            this.socket = io(CONFIG.SERVER_URL, {
                auth: { token: jwtToken },
                transports: ['websocket']
            });

            this.setupSocketListeners();

            const timeout = setTimeout(() => {
                reject(new Error('Connection timeout'));
            }, 10000);

            this.socket.once('connect', () => {
                clearTimeout(timeout);
                this.isConnected = true;
                this.log('✅ Connected to Vietnamese market data server', 'SUCCESS');
                resolve();
            });

            this.socket.once('connect_error', (error) => {
                clearTimeout(timeout);
                reject(error);
            });
        });
    }

    setupSocketListeners() {
        // Connection events
        this.socket.on('disconnect', () => {
            this.isConnected = false;
            this.log('❌ Disconnected from server', 'ERROR');
        });

        this.socket.on('connection_status', (data) => {
            this.log(`🔐 Connection status: ${JSON.stringify(data)}`, 'SUCCESS');
        });

        this.socket.on('auth_error', (error) => {
            this.log(`🚫 Authentication error: ${error.message}`, 'ERROR');
        });

        // MQTT events
        this.socket.on('mqtt_status', (data) => {
            this.log(`📡 MQTT Status: ${data.status}`, 'INFO');
        });

        this.socket.on('mqtt_error', (error) => {
            this.log(`❌ MQTT Error: ${error.error}`, 'ERROR');
        });

        // Subscription events
        this.socket.on('subscription_confirmed', (data) => {
            this.subscriptions.add(data.topic);
            this.log(`✅ Subscription confirmed: ${data.type} for ${data.symbol || data.indexCode}`, 'SUCCESS');
        });

        this.socket.on('subscription_error', (error) => {
            this.log(`❌ Subscription error: ${JSON.stringify(error)}`, 'ERROR');
        });

        // Market data
        this.socket.on('market_data', (data) => {
            const symbol = data.data.symbol || data.data.indexCode || 'Unknown';

            if (data.topic.includes('tick')) {
                this.log(`📈 TICK [${symbol}]: Price=${data.data.matchPrice}, Qty=${data.data.matchQtty}, Side=${data.data.side}, Time=${data.data.sendingTime}`, 'DATA');
            } else if (data.topic.includes('stockinfo')) {
                this.log(`📋 STOCK INFO [${symbol}]: Current=${data.data.currentPrice}, Open=${data.data.openPrice}, High=${data.data.highPrice}, Low=${data.data.lowPrice}, Volume=${data.data.volume}`, 'DATA');
            } else if (data.topic.includes('index')) {
                this.log(`📊 INDEX [${symbol}]: Value=${data.data.indexValue}, Change=${data.data.changeValue} (${data.data.changePercent}%)`, 'DATA');
            } else if (data.topic.includes('topprice')) {
                this.log(`💰 TOP PRICE [${symbol}]: Bid=${data.data.bidPrice1}(${data.data.bidQtty1}), Ask=${data.data.offerPrice1}(${data.data.offerQtty1})`, 'DATA');
            } else {
                this.log(`📊 DATA [${symbol}]: ${JSON.stringify(data.data)}`, 'DATA');
            }
        });

        // Utility events
        this.socket.on('current_subscriptions', (data) => {
            this.log(`📋 Current subscriptions: Client=${data.subscriptions.length}, MQTT=${data.mqttSubscriptions.length}`, 'INFO');
        });

        this.socket.on('pong', (data) => {
            this.log(`🏓 Pong received: MQTT=${data.mqttConnected}`, 'INFO');
        });

        this.socket.on('error', (error) => {
            this.log(`❌ Socket error: ${JSON.stringify(error)}`, 'ERROR');
        });
    }

    subscribeToSymbol(symbol, types = ['tick', 'stock_info', 'top_price']) {
        if (!this.isConnected) {
            this.log('❌ Not connected to server', 'ERROR');
            return;
        }

        this.log(`🔔 Subscribing to ${symbol} for: ${types.join(', ')}`);

        types.forEach(type => {
            switch(type) {
                case 'tick':
                    this.socket.emit('subscribe_tick', { symbol });
                    break;
                case 'stock_info':
                    this.socket.emit('subscribe_stock_info', { symbol });
                    break;
                case 'top_price':
                    this.socket.emit('subscribe_top_price', { symbol });
                    break;
                case 'ohlc':
                    this.socket.emit('subscribe_ohlc', { symbol, resolution: '1D' });
                    break;
            }
        });
    }

    subscribeToIndex(indexCode) {
        if (!this.isConnected) {
            this.log('❌ Not connected to server', 'ERROR');
            return;
        }

        this.log(`📊 Subscribing to index: ${indexCode}`);
        this.socket.emit('subscribe_market_index', { symbol: indexCode });
    }

    async runTests() {
        this.log('🚀 Starting comprehensive Vietnamese market data tests...', 'INFO');

        // Test VNINDEX
        this.log('📈 Testing VNINDEX (Vietnamese stock market index)...', 'INFO');
        this.subscribeToIndex('VNINDEX');

        await this.sleep(1000);

        // Test VIC (Vingroup)
        this.log('🏢 Testing VIC (Vingroup) - Vietnam\'s largest conglomerate...', 'INFO');
        this.subscribeToSymbol('VIC', ['tick', 'stock_info', 'top_price']);

        await this.sleep(1000);

        // Test other major Vietnamese stocks
        const majorStocks = ['VCB', 'FPT', 'MSN', 'VHM'];
        for (const stock of majorStocks) {
            this.log(`📊 Testing ${stock}...`, 'INFO');
            this.subscribeToSymbol(stock, ['tick', 'stock_info']);
            await this.sleep(500);
        }

        this.log('✅ All subscriptions sent. Waiting for market data...', 'SUCCESS');
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    showMenu() {
        console.log('\n🇻🇳 Vietnamese Market Data Test Menu:');
        console.log('1. Test VNINDEX');
        console.log('2. Test VIC (Vingroup)');
        console.log('3. Test VCB (Vietcombank)');
        console.log('4. Test FPT Corporation');
        console.log('5. Test All Major Stocks');
        console.log('6. Subscribe to custom symbol');
        console.log('7. Get current subscriptions');
        console.log('8. Ping server');
        console.log('9. Run comprehensive tests');
        console.log('0. Quit');
        console.log('');
    }

    async startInteractiveMode() {
        this.showMenu();

        const handleInput = (input) => {
            const choice = input.trim();

            switch(choice) {
                case '1':
                    this.subscribeToIndex('VNINDEX');
                    break;
                case '2':
                    this.subscribeToSymbol('VIC', ['tick', 'stock_info', 'top_price']);
                    break;
                case '3':
                    this.subscribeToSymbol('VCB', ['tick', 'stock_info']);
                    break;
                case '4':
                    this.subscribeToSymbol('FPT', ['tick', 'stock_info']);
                    break;
                case '5':
                    this.runTests();
                    break;
                case '6':
                    this.rl.question('Enter symbol: ', (symbol) => {
                        this.subscribeToSymbol(symbol.toUpperCase(), ['tick', 'stock_info']);
                        this.rl.prompt();
                    });
                    return;
                case '7':
                    if (this.socket) {
                        this.socket.emit('get_subscriptions');
                    }
                    break;
                case '8':
                    if (this.socket) {
                        this.socket.emit('ping');
                    }
                    break;
                case '9':
                    this.runTests();
                    break;
                case '0':
                case 'quit':
                case 'exit':
                    this.log('👋 Goodbye!', 'INFO');
                    process.exit(0);
                    break;
                case 'help':
                    this.showMenu();
                    break;
                default:
                    console.log('Invalid choice. Type "help" for menu.');
            }

            this.rl.prompt();
        };

        this.rl.on('line', handleInput);
        this.rl.prompt();
    }

    disconnect() {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
            this.isConnected = false;
        }
    }
}

// Main execution
async function main() {
    console.log('🇻🇳 Vietnamese Market Data Socket Test');
    console.log('=====================================');
    console.log('Testing VNINDEX and VIC symbol data feeds\n');

    const tester = new VietnameseMarketTester();

    // Handle graceful shutdown
    process.on('SIGINT', () => {
        console.log('\n💀 Shutting down gracefully...');
        tester.disconnect();
        process.exit(0);
    });

    // Get JWT token
    const jwtToken = process.env.JWT_TOKEN || await new Promise((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        rl.question('Enter your JWT token: ', (token) => {
            rl.close();
            resolve(token);
        });
    });

    if (!jwtToken) {
        console.error('❌ JWT token is required');
        process.exit(1);
    }

    try {
        // Connect to server
        await tester.connect(jwtToken);

        // Check command line arguments
        const args = process.argv.slice(2);
        if (args.includes('--auto')) {
            // Auto mode - run all tests
            await tester.runTests();

            // Keep running for 30 seconds to collect data
            console.log('📊 Collecting data for 30 seconds...');
            setTimeout(() => {
                tester.log('⏰ Test completed', 'SUCCESS');
                process.exit(0);
            }, 30000);
        } else {
            // Interactive mode
            await tester.startInteractiveMode();
        }

    } catch (error) {
        console.error(`❌ Failed to connect: ${error.message}`);
        process.exit(1);
    }
}

// Export for use as module
module.exports = VietnameseMarketTester;

// Run if called directly
if (require.main === module) {
    main().catch(console.error);
}